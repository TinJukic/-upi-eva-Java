package hr.fer.oprpp1.custom.collections;

/**
 * Processor class.
 * @author Tin Jukić
 *
 */
public class Processor {
	/**
	 * Processes the given element.
	 * @param value element to be processed
	 */
	public void process(Object value) { }
}
