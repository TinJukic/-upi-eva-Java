package hr.fer.oprpp1.custom.collections;

/**
 * Custom exception for when the stack is empty.
 * @author Tin Jukić
 *
 */
public class EmptyStackException extends RuntimeException {
	
}
