package hr.fer.zemris.java.hw06.shell;

/**
 * Shell status enum.
 * @author Tin Jukić
 *
 */
public enum ShellStatus {
	CONTINUE, TERMINATE
}
