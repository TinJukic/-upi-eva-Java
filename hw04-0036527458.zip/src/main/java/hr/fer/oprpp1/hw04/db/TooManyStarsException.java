package hr.fer.oprpp1.hw04.db;

/**
 * Custom exception for operator LIKE.
 * @author Tin Jukić
 *
 */
public class TooManyStarsException extends Exception {

}
