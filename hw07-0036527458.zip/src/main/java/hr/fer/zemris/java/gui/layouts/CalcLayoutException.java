package hr.fer.zemris.java.gui.layouts;

/**
 * Custom exception.
 * @author Tin Jukić
 *
 */
public class CalcLayoutException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
