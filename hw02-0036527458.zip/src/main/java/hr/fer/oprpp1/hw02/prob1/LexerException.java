package hr.fer.oprpp1.hw02.prob1;

/**
 * 
 * thrown when the Lexer finds an error while processing
 * @author Tin Jukić
 *
 */

public class LexerException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return super.getMessage();
	}
}
