package hr.fer.oprpp1.hw02.prob1;

/**
 * 
 * @author Tin Jukić
 * @enum has all types that a token can have
 *
 */

public enum TokenType {
	EOF, WORD, NUMBER, SYMBOL
}
