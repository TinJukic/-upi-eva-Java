package hr.fer.oprpp1.hw02.prob1;

/**
 * 
 * @author Tin Jukić
 * @enum has all the states that lexer can be in
 *
 */
public enum LexerState {
	BASIC, EXTENDED
}
