package hr.fer.oprpp1.custom.scripting.elems;

/**
 * 
 * @author Tin Jukić
 * @Elements will be used to for the representation of expressions
 *
 */

public class Element {

	/**
	 * 
	 * default method
	 * @return empty string
	 */
	public String asText() {
		// here it should return an empty string
		return "";
	}
	
}
