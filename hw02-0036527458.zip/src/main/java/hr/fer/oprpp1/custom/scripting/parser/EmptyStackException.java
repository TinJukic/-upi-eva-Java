package hr.fer.oprpp1.custom.scripting.parser;

/**
 * 
 * @throws EmptyStackException when the send stack is empty (custom exception)
 *
 */

public class EmptyStackException extends RuntimeException {
	
}
