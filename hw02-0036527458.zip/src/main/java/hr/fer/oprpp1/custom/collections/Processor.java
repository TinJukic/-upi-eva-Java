package hr.fer.oprpp1.custom.collections;

/**
 * 
 * @author Tin Jukić
 * @method process() here it is implemented as an empty method
 *
 */

public interface Processor {
	/**
	 * processes given value
	 * @param value
	 */
	void process(Object value);
}
