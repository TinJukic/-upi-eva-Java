package hr.fer.oprpp1.custom.scripting.nodes;

/**
 * 
 * @author Tin Jukić
 * @DocumentNode a node representing an entire document
 *
 */

public class DocumentNode extends Node {

}
